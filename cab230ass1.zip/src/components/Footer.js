function Footer() {
    return (
        <div className="Footer" style={{marginTop: '2vh'}}>
            <p>All data is from IMDB, Metacritic and RottenTomatoes.</p>
            <p>© 2023 Xinyu (Johnny) Yang</p>
        </div>
    )
}

export default Footer;